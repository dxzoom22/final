<html>
  <head>
    <script type = "text / javascript" src = "https://www.gstatic.com/charts/loader.js" > </script>       
    <tipo de script=>    
      google.charts.load ("current", {packages: ["corechart"]});
      google.charts.setOnLoadCallback (drawChart);
      função drawChart () {
        var data = google.visualization.arrayToDataTable ([
          ['Tarefa', 'Horas por dia'],
          ['Trabalho', 11],
          ['Comer', 2],
          ['Comutar', 2],
          ['Assista TV', 2],
          ['Dormir', 7]
        ]);

        var options = {
          title: 'Minhas atividades especializadas',
          is3D: verdadeiro ,
        };

        var chart = novo google.visualization.PieChart (document.getElementById ('piechart_3d'));
        chart.draw (dados, opções);
      }
    </script>
  </head>
  <body>
    <div id = "piechart_3d" style = " width : 900px ; height : 500px ; " > </div>          
  </body>
</html>